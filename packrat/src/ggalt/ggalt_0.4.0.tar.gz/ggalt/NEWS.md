0.4.0
=====================
* Fixed `coord_proj()`
* Removed pokemon colors (et al)
* Added dotted-gridline guide for `geom\_dumbbell()`
* Complete parameter re-write to `geom\_dumbbell()`
* New geoms & stats by Ben Bolker, Jan Schulz and Carson Sievert
* Ben Marwick also did his best to keep up with my fat-fingering but I'm snuck a few in before the release

0.3.0
=====================
* Added `geom_lollipop()` to make it easer to create lollipop charts

0.2.0
=====================
* Incorporated ProPublica StateFace font
* `geom_encircle()` contributed by Ben Bolker

0.1.5
=====================
* Pokemon discrete color scales!
* `byte_format` (et al) scales (e.g. 10000 => 10 Kb)
