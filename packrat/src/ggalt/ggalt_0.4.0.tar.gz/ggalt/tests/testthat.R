library(testthat)
library(ggalt)

test_check("ggalt")
