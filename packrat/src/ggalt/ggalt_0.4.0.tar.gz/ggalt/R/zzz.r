.onAttach <- function(...) {

  if (!interactive()) return()

  # packageStartupMessage(paste0("ggalt is under *active* development. ",
  #                              "See https://github.com/hrbrmstr/ggalt for changes"))

}

