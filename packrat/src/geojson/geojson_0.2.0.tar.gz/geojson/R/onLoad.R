.onLoad <- function(libname, pkgname) {
  linting_opts()
}
