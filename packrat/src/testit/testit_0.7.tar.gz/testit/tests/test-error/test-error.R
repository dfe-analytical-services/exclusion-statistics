stop('An intentional error!')
